/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.exam;

/**
 *
 * @author mohsy
 */
public class ProductCatalogue {
    productList<Product> List = new productList<>();

    public ProductCatalogue() {
    }
    public void AddProduct(){
        
    }
     public void DeleteProduct(){
        
    }
      public void DisplayAllInAciveProducts(){
        
    }
     public void InActiveProduct(){
        
    }  

    private static class productList<T> {

        public productList() {
        }
    }
}
