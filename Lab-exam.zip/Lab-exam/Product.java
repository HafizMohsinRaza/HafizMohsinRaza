package lab.exam;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mohsy
 */
public class Product {

    public Product(String ProductName, String ProductCategory, String Description, int Price, String Status) {
        this.ProductName = ProductName;
        this.ProductCategory = ProductCategory;
        this.Description = Description;
        this.Price = Price;
        this.Status = Status;
    }
    public String ProductName;
    public String ProductCategory;
    public String Description;
    public int Price;

    Product() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getProductName() {
        return ProductName;
    }

    public void setProductName(String ProductName) {
        this.ProductName = ProductName;
    }

    public String getProductCategory() {
        return ProductCategory;
    }

    public void setProductCategory(String ProductCategory) {
        this.ProductCategory = ProductCategory;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public int getPrice() {
        return Price;
    }

    public void setPrice(int Price) {
        this.Price = Price;
    }

    public String getStatus() {
        return Status;
    }

    
    public String Status;
    
    public void makeIncentive(String Status){
        if(Status==null){
            System.out.println("make status inactive");
        }
    }

    boolean get() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   public class Email{

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public Email(String username, String password) {
            this.username = username;
            this.password = password;
        }

        @Override
        public String toString() {
           System.out.println("Sample Product belongs to Cloth Category with price Rs.99");
           System.out.println("This is the description of product");

           return "Email{" + "username=" + username + ", password=" + password + '}';
        }
      public String username;
      public String password;
       
   }

        
    
    
}
